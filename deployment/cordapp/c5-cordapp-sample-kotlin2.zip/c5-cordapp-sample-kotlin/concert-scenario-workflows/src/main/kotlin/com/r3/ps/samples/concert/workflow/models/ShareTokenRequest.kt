package com.r3.ps.samples.concert.workflow.models

data class ShareTokenRequest(
    val id: String,
    val shareWith: String
)