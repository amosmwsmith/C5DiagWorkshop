package com.r3.ps.samples.concert.workflow.models

data class SplitTokensRequest(
    val tokenId: String,
    val chunks: List<Double>
)