package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.FungibleToken
import com.r3.ps.samples.concert.state.TicketToken
import com.r3.ps.samples.concert.workflow.models.ListCashTokensResponse
import com.r3.ps.samples.concert.workflow.models.ListTicketTokensResponse
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef
import kotlin.math.abs

class SplitTicketTokensFlow(
    private val tokenId: String,
    private val chunksNumbers: List<Double>
) : AbstractFlow(), SubFlow<ListTicketTokensResponse>  {
    @Suspendable
    override fun call(): ListTicketTokensResponse {
        try {
            val tokenStateRef = flowEngine.subFlow(ListTicketTokens(listOf(tokenId))).single()
            val chunks: MutableList<TicketToken> = mutableListOf()
            with(tokenStateRef.state.contractState) {
                val wantInTotal = chunksNumbers.sum()
                val remains = value - wantInTotal
                if (remains < 0) throw IllegalArgumentException(
                    "$id has not enough value to split. Required ${
                        abs(
                            remains
                        )
                    } more!"
                )
                chunks.addAll(chunksNumbers.map {
                    TicketToken(
                        issuer = issuer,
                        holder = holder,
                        description = description,
                        price = price,
                        value = it
                    )
                })
                if (remains > 0) {
                    chunks.add(
                        TicketToken(
                            id  = id,
                            issuer = issuer,
                            holder = holder,
                            description = description,
                            price = price,
                            value = remains
                        )
                    )
                }
            }
            flowEngine.subFlow(SplitFungibleToken(tokenStateRef as StateAndRef<FungibleToken>, chunks.toList()))
            return ListTicketTokensResponse(chunks.map { it.toModel() }, chunks.size)
        } catch (e: Exception) {
            logger.error("SplitTicketTokens failed because: $e")
            throw e
        }
    }
}