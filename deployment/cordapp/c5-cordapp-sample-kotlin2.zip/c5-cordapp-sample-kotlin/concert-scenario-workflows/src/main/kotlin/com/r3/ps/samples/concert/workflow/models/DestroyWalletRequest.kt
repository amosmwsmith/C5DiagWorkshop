package com.r3.ps.samples.concert.workflow.models

data class DestroyWalletRequest(
    val id: String
)