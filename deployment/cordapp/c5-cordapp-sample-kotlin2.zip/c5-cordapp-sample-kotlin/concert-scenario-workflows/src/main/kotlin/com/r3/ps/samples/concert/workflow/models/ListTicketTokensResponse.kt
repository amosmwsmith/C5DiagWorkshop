package com.r3.ps.samples.concert.workflow.models

import com.r3.ps.samples.concert.state.models.TicketTokenModel

data class ListTicketTokensResponse(
    val tokens: List<TicketTokenModel>?,
    val totalCount: Int,
)
