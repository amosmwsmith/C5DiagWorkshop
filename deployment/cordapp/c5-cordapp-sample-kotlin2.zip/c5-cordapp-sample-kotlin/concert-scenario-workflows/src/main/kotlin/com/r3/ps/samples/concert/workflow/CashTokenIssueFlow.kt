package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.workflow.models.IssueTokenRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable

@InitiatingFlow(protocol = "cash")
class CashTokenIssueFlow : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val issueRequest = requestBody.getRequestBodyAs(json, IssueTokenRequest::class.java)
            val issuer = findParty(issueRequest.issuer).owningKey
            val token = CashToken(
                issuer = issuer,
                holder = issuer,
                value = issueRequest.value
            )
            return flowEngine.subFlow(TokenIssueFlow(token))
        } catch (e: Exception) {
            logger.error("CashToken Issuance failed because: $e")
            throw e
        }
    }
}