package com.r3.ps.samples.concert.workflow.models

data class PurchaseTicketsRequest (
    val payeeId: String,
    val payerId: String,
    val description: String,
    val amount: Double
)

