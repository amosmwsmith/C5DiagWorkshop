package com.r3.ps.samples.concert.workflow.models

data class DepositTokenRequest(
    val walletId: String,
    val tokenId: String,
    val amount: Double? = null
)