package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import com.r3.ps.samples.concert.state.FungibleToken
import net.corda.v5.application.flows.InitiatedBy
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.ResponderFlow
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable
import java.security.PublicKey
import java.util.*

@InitiatingFlow(protocol = "redeem-token")
class RedeemTokenFlow(
    private val tokenIds: List<UUID>
) : AbstractFlow(), SubFlow<Unit> {
    @Suspendable
    override fun call() {
        try {
            val tokens = ledger.findUnconsumedStatesByType(FungibleToken::class.java).map { it }
                .sortedBy { it.state.contractState.id }.filter {
                    tokenIds.contains(it.state.contractState.id)
                }
            val signatories = mutableSetOf<PublicKey>()
            val holders = mutableSetOf<PublicKey>()
            val self = tokens.first().state.contractState.issuer
            tokens.forEach {
                with(it.state.contractState) {
                    if (!memberLookup.myInfo().ledgerKeys.contains(issuer)) {
                        throw IllegalArgumentException("${memberLookup.myInfo().name} can't redeem token on behalf of ${issuer.toPrettyName()}")
                    }
                    signatories.addAll(participants)
                    holders.addAll(participants - self)
                }
            }
            val stx = ledger.transactionBuilder
                .setNotary(notary)
                .addCommand(FungibleTokenContract.Commands.Redeem())
                .addInputStates(tokens.map { it.ref })
                .setTimeWindowUntil(defaultTimeWindow)
                .addSignatories(signatories)
                .toSignedTransaction()
            val sessions = holders.map { flowMessaging.initiateFlow(it.toMember()) }
            ledger.finalize(stx, sessions)
        } catch (e: Exception) {
            logger.error("Redeem flow for tokens: ${tokenIds.map { it.toString() }} failed because: ${e.message}")
            throw e
        }
    }
}

@InitiatedBy(protocol = "redeem-token")
class RedeemTokenResponderFlow : AbstractFlow(), ResponderFlow {
    @Suspendable
    override fun call(session: FlowSession) {
        ledger.receiveFinality(session) {
            logger.info("RedeemTokenResponder: hiya! I am ${memberLookup.myInfo().name}")
        }
    }
}