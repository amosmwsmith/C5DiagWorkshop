package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import com.r3.ps.samples.concert.state.FungibleToken
import net.corda.v5.application.flows.InitiatedBy
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.ResponderFlow
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef

/**
 * Request to the current token's holder to give the ownership
 */
@InitiatingFlow(protocol = "ask-move-token")
class AskForMoveFungibleToken(
    private val token: StateAndRef<FungibleToken>,
    private val newToken: FungibleToken,
) : AbstractFlow(), SubFlow<FungibleToken> {
    @Suspendable
    override fun call(): FungibleToken {
        val newHolder = newToken.holder
        if (!memberLookup.myInfo().ledgerKeys.contains(newToken.holder))
            throw IllegalArgumentException("Token move request should be initiated by new holder (${token.state.contractState.holder.toPrettyName()})")

        val sessions = token.state.contractState.participants.map { flowMessaging.initiateFlow(it.toMember()) }
        val signatories = token.state.contractState.participants + newHolder
        val stx = ledger.transactionBuilder
            .setNotary(notary)
            .addCommand(FungibleTokenContract.Commands.Move())
            .addInputState(token.ref)
            .addOutputState(newToken)
            .setTimeWindowUntil(defaultTimeWindow)
            .addSignatories(signatories)
            .toSignedTransaction()
        ledger.finalize(stx, sessions)
        return newToken
    }
}

@InitiatedBy(protocol = "ask-move-token")
class AskForMoveFungibleTokenResponder : AbstractFlow(), ResponderFlow {
    @Suspendable
    override fun call(session: FlowSession) {
        ledger.receiveFinality(session) {
            logger.info("MoveFungibleTokenResponder: hiya! I am ${memberLookup.myInfo().name}")
        }
    }
}