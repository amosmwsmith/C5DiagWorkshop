package com.r3.ps.samples.concert.workflow.models

data class IssueTokenRequest(
    val value: Double,
    val issuer: String
)