package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.WalletContract
import com.r3.ps.samples.concert.workflow.models.DepositTokenRequest
import com.r3.ps.samples.concert.workflow.models.ListCashTokensResponse
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable
import kotlin.Exception

class DepositCashToken: AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val request = requestBody.getRequestBodyAs(json, DepositTokenRequest::class.java)
            val tokenStateRef = flowEngine.subFlow(ListCashTokens(request.tokenId)).getOrNull(0)
                ?: throw Exception("Cash token with id ${request.tokenId} not found")
            val walletStateRef = flowEngine.subFlow(ListWalletsFlow(request.walletId)).getOrNull(0)
                ?: throw Exception("Wallet with id ${request.tokenId} not found")
            val token = tokenStateRef.state.contractState
            val wallet = walletStateRef.state.contractState

            val afterDeposit = if (request.amount != null) {
                if (request.amount == token.value) wallet.deposit(token)
                else if (request.amount > token.value) throw Exception("Not enough value to deposit funds. ${request.amount - token.value} more required.")
                else {
                    val afterSplit: ListCashTokensResponse =
                        flowEngine.subFlow(SplitCashTokensFlow(token.id.toString(), listOf(request.amount)))
                    val filteredTokens = afterSplit.tokens?.filter { it.value == request.amount }
                        ?: throw Exception("Couldn't deposit because split failed")
                    val assetId =
                        (filteredTokens.getOrNull(0) ?: throw Exception("Couldn't deposit because split failed")).id
                    val asset = (flowEngine.subFlow(ListCashTokens(assetId.toString())).getOrNull(0) ?: throw Exception(
                        "Couldn't deposit because split failed"
                    )).state.contractState
                    wallet.deposit(asset)
                }
            } else wallet.deposit(token)

            val stx = ledger.transactionBuilder
                .setNotary(notary)
                .setTimeWindowUntil(defaultTimeWindow)
                .addInputState(walletStateRef.ref)
                .addOutputState(afterDeposit)
                .addSignatories(wallet.participants)
                .addCommand(WalletContract.Commands.Deposit())
                .toSignedTransaction()
            ledger.finalize(stx, listOf())
            return json.format(afterDeposit.toModel())
        } catch (e : Exception) {
            e.printStackTrace()
            throw e
        }
    }
}