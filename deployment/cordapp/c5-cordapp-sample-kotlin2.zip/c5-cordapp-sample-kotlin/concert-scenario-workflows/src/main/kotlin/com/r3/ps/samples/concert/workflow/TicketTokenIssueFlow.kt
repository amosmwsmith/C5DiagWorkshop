package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.TicketToken
import com.r3.ps.samples.concert.workflow.models.IssueTicketTokenRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable

@InitiatingFlow(protocol = "ticket")
class TicketTokenIssueFlow : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val issueRequest = requestBody.getRequestBodyAs(json, IssueTicketTokenRequest::class.java)
            val issuer = findParty(issueRequest.issuer).owningKey
            val token = TicketToken(
                issuer = issuer,
                holder = issuer,
                value = issueRequest.value,
                description = issueRequest.description,
                price = issueRequest.price
            )
            return flowEngine.subFlow(TokenIssueFlow(token))
        } catch (e: Exception) {
            logger.error("Ticket Token issuance failed because: $e")
            throw e
        }
    }
}



