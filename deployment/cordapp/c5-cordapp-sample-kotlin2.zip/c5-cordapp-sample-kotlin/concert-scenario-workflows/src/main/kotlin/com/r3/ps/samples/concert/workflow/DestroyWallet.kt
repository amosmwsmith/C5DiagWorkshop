package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.WalletContract
import com.r3.ps.samples.concert.workflow.models.DestroyWalletRequest
import net.corda.v5.application.flows.*
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable

@InitiatingFlow(protocol = "destroy-wallet")
class DestroyWallet : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String =
        try {
            val request = requestBody.getRequestBodyAs(json, DestroyWalletRequest::class.java)
            val wallet = flowEngine.subFlow(ListWalletsFlow(listOf(request.id))).singleOrNull()
                ?: throw IllegalArgumentException("Wallet not found")
            val registeredWith = wallet.state.contractState.registeredWith
            if (!memberLookup.myInfo().ledgerKeys.contains(registeredWith))
                throw IllegalArgumentException("Only ${registeredWith.toPrettyName()} can close wallet with id: ${request.id}")
            val signatories = wallet.state.contractState.participants

            // TODO: redeem the tokens if any

            val stx = ledger.transactionBuilder
                .setNotary(notary)
                .addCommand(WalletContract.Commands.Close())
                .addInputStates(wallet.ref)
                .setTimeWindowUntil(defaultTimeWindow)
                .addSignatories(signatories)
                .toSignedTransaction()
            val sessions = (signatories - registeredWith).map { flowMessaging.initiateFlow(it.toMember()) }
            json.format(ledger.finalize(stx, sessions).id)
        } catch (e: Exception) {
            logger.error(e.message)
            "Error: " + e.message.toString()
        }
}

@InitiatedBy(protocol = "destroy-wallet")
class DestroyWalletResponder : AbstractFlow(), ResponderFlow {
    @Suspendable
    override fun call(session: FlowSession) {
        ledger.receiveFinality(session) {
            logger.info("DestroyWalletResponder: hiya! I am ${memberLookup.myInfo().name}")
        }
    }
}