package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import com.r3.ps.samples.concert.state.FungibleToken
import net.corda.v5.application.flows.InitiatedBy
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.ResponderFlow
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef

@InitiatingFlow(protocol = "moveToken")
class MoveFungibleToken(
    private val token: StateAndRef<FungibleToken>,
    private val newToken: FungibleToken,
) : AbstractFlow(), SubFlow<FungibleToken> {
    @Suspendable
    override fun call(): FungibleToken {
        try {
            val stx = ledger.transactionBuilder
                .setTimeWindowUntil(defaultTimeWindow)
                .setNotary(notary)
                .addInputState(token.ref)
                .addOutputState(newToken)
                .addCommand(FungibleTokenContract.Commands.Move())
                .addSignatories((token.state.contractState.participants + newToken.holder).toSet())
                .toSignedTransaction()
            val sessions = (token.state.contractState.participants + newToken.holder - token.state.contractState.holder).map { flowMessaging.initiateFlow(it.toMember()) }
            logger.info("FungibleTokenMove: sessions size is ${sessions.size}")
            ledger.finalize(stx, sessions)
            return newToken
        } catch (e : Exception) {
            e.printStackTrace()
            logger.error("FungibleToken move failed because ${e.message}")
            throw e
        }
    }
}

@InitiatedBy(protocol = "moveToken")
class MoveFungibleTokenResponder : AbstractFlow(), ResponderFlow {
    @Suspendable
    override fun call(session: FlowSession) {
        logger.info("MoveFungibleTokenResponder: my identity is ${memberLookup.myInfo().name}")
        ledger.receiveFinality(session) {}
    }
}