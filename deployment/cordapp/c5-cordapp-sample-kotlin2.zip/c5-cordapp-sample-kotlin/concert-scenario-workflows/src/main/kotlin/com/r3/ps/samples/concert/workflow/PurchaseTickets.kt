package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.WalletContract
import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.state.TicketToken
import com.r3.ps.samples.concert.state.Wallet
import com.r3.ps.samples.concert.workflow.models.ListTicketTokensResponse
import com.r3.ps.samples.concert.workflow.models.PurchaseTicketsRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef

class PurchaseTickets: AbstractFlow(), ClientStartableFlow {

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            // payee <- pay to; payer - paying
            val request = requestBody.getRequestBodyAs(json, PurchaseTicketsRequest::class.java)
            if (request.amount <= 0) throw Exception("Invalid tickets amount to purchase (${request.amount})")
            var payeeStateRef: StateAndRef<Wallet>? = null
            var payerStateRef: StateAndRef<Wallet>? = null
            flowEngine.subFlow(ListWalletsFlow(listOf(request.payerId, request.payeeId))).forEach {
                if (it.state.contractState.id.toString() == request.payerId) payerStateRef = it
                if (it.state.contractState.id.toString() == request.payeeId) payeeStateRef = it
            }
            if (payerStateRef == null || payeeStateRef == null) throw Exception("Payee or Payer wallet was not found")
            // Does payee have valid tickets? 🎫
            val payeeWallet = payeeStateRef!!.state.contractState
            val selectedTickets = payeeWallet.listTicketTokens().filter { it.description == request.description }.sortedBy { it.price }
            if (selectedTickets.sumOf { it.value } < request.amount) throw Exception("Payee doesn't have ${request.amount} tickets for ${request.description}")
            // Does payer have enough cash? 💸
//            val amountToPay = with (payeeWallet.listTicketTokens().filter { it.description == request.description }[0]) {
//                this.price * request.amount
//            }

            val payerWallet = payerStateRef!!.state.contractState
            val currentBalance = payerWallet.balance().first

            var payeeAfterPurchase = payeeWallet
            var payerAfterPurchase = payerWallet

            var ticketsCount = request.amount
            val ticketsToPop: MutableList<TicketToken> = mutableListOf()
            var amountToPay = 0.0

            selectedTickets.forEach {
                if (ticketsCount != 0.0) {
                    if (it.value <= ticketsCount) {
                        ticketsToPop.add(it)
                        amountToPay += it.value * it.price
                        balanceCheck(amountToPay, currentBalance)
                        ticketsCount -= it.value
                        payeeAfterPurchase = payeeAfterPurchase.pop(it)
                        payerAfterPurchase = payerAfterPurchase.deposit(it)
                    } else {
                        amountToPay += ticketsCount * it.price
                        balanceCheck(amountToPay, currentBalance)
                        // split tickets situation
                        val splitTickets = flowEngine.subFlow(SplitTicketTokensFlow(it.id.toString(), listOf(ticketsCount))).tokens!!.map { tk -> tk.toState() }
                        val soldTickets = splitTickets.filter { tk -> tk.value == ticketsCount }[0]
                        ticketsCount = 0.0
                        payeeAfterPurchase = payeeAfterPurchase.pop(it).deposit(splitTickets - soldTickets)
                        payerAfterPurchase = payerAfterPurchase.deposit(soldTickets)
                    }
                }
            }

            var cashCount = amountToPay
            val cashToPop: MutableList<CashToken> = mutableListOf()

            payerWallet.listCashTokens().forEach {
                if (cashCount != 0.0) {
                    if (it.value <= cashCount) {
                        cashToPop.add(it)
                        cashCount -= it.value
                        payerAfterPurchase = payerAfterPurchase.pop(it)
                        payeeAfterPurchase = payeeAfterPurchase.deposit(it)
                    } else {
                        val splitCash = flowEngine.subFlow(SplitCashTokensFlow(it.id.toString(), listOf(cashCount))).tokens!!.map { tk -> tk.toState() }
                        val spentCash = splitCash.filter { ch -> ch.value == cashCount }[0]
                        cashCount = 0.0
                        payerAfterPurchase = payerAfterPurchase.pop(it).deposit(splitCash - spentCash)
                        payeeAfterPurchase = payeeAfterPurchase.deposit(spentCash)
                    }
                }
            }

            // We are good to do swap now! 🙌

            val stx = ledger.transactionBuilder
                .setNotary(notary)
                .setTimeWindowUntil(defaultTimeWindow)
                .addCommand(WalletContract.Commands.Purchase())
                .addInputState(payeeStateRef!!.ref)
                .addInputState(payerStateRef!!.ref)
                .addOutputState(payeeAfterPurchase)
                .addOutputState(payerAfterPurchase)
                .addSignatories((payeeAfterPurchase.participants+payerAfterPurchase.participants).toSet())
                .toSignedTransaction()

            ledger.finalize(stx, emptyList())
            return json.format(listOf(payeeAfterPurchase.toModel(),payerAfterPurchase.toModel()))

        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
    }
    private fun balanceCheck(amountToPay: Double, currentBalance: Double) { if (currentBalance < amountToPay) throw Exception("Payer doesn't have enough cash to pay. Required at least: $amountToPay but available $currentBalance") }
}