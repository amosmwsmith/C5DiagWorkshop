package com.r3.ps.samples.concert.contract

import com.r3.ps.samples.concert.state.FungibleToken
import net.corda.v5.ledger.utxo.Command
import net.corda.v5.ledger.utxo.Contract
import net.corda.v5.ledger.utxo.transaction.UtxoLedgerTransaction
import java.security.PublicKey

class FungibleTokenContract : Contract {

    interface Commands {
        class Issue: Command
        class Move: Command
        class Redeem: Command
        class Split: Command

        class Share: Command
    }

    override fun verify(transaction: UtxoLedgerTransaction) {
        when (val command = transaction.commands.single()) {
            is Commands.Issue -> verifyIssue(transaction)
            is Commands.Move -> verifyMove(transaction)
            is Commands.Redeem -> verifyRedeem(transaction)
            is Commands.Split -> verifySplit(transaction)
            is Commands.Share -> verifyShare(transaction)
            else ->
                throw IllegalArgumentException("Incorrect action on FungibleToken: ${command::class.java.name}")
        }

        verifyParticipants(transaction)
    }

    private fun UtxoLedgerTransaction.getInputTokens(): List<FungibleToken> = getInputStates(FungibleToken::class.java)
    private fun UtxoLedgerTransaction.getOutputTokens(): List<FungibleToken> = getOutputStates(FungibleToken::class.java)

    private fun verifyIssue(tx: UtxoLedgerTransaction) {
        require(tx.inputContractStates.isEmpty()) {
            "Token issuance doesn't require any input states"
        }
        val tokens = tx.getOutputTokens()
        require(tokens.isNotEmpty()) {
            "Token issuance should have fungible token(s) as output"
        }
        tokens.forEach {
            token ->
            require(token.issuer == token.holder) {
                "Issuer and holder should be the same at the time of issuance (token id: ${token.id}"
            }
        }
    }
    private fun verifyMove(tx: UtxoLedgerTransaction) {
        val presentTokens = tx.getInputTokens()
        val futureTokens = tx.getOutputTokens()
        require(presentTokens.size == futureTokens.size && presentTokens.isNotEmpty()) {
            "Tokens amount can't change on tokens movement"
        }
        presentTokens.forEach {
            presentToken ->
            val futureToken = futureTokens.last { token -> token.id == presentToken.id}
            require(futureToken.issuer == presentToken.issuer) {
                "[TokenId: $futureToken.id]: Issuer shouldn't change during tokens movement"
            }
            require(futureToken.holder != presentToken.holder) {
                "[TokenId: $futureToken.id]: Holder should change during tokens movement."
            }
            require(futureToken.value == presentToken.value) {
                "[TokenId: $futureToken.id]: Value shouldn't change during tokens movement."
            }
        }
    }
    private fun verifyRedeem(tx: UtxoLedgerTransaction) {
        require(tx.getInputTokens().isNotEmpty()) {
            "Tokens redemption requires tokens to redeem"
        }
        require(tx.getOutputTokens().isEmpty()) {
            "Tokens redemption shouldn't have any output"
        }
    }
    private fun verifySplit(tx: UtxoLedgerTransaction) {
        require(tx.getInputTokens().size == 1) {
            "One token state should be present for split action"
        }
        require(tx.getInputTokens().size < tx.getOutputTokens().size) {
            "Amount of tokens after split should be more than it used to be before"
        }
//        tx.getInputTokens().forEach {
//            presentToken ->
//
//            require(tx.getOutputTokens().firstOrNull { token ->
//                token.id == presentToken.id
//            } == null) {
//                "Tokens after split should have new ids"
//            }
//        }
    }

    private fun verifyShare(tx: UtxoLedgerTransaction) {}

    private fun verifyParticipants(tx: UtxoLedgerTransaction) {
        val participants = tx.signatories
        val expected : MutableSet<PublicKey> = mutableSetOf()
        expected.addAll(gatherParticipants(tx.getInputTokens()))
        expected.addAll(gatherParticipants(tx.getOutputTokens()))
        require(participants.containsAll(expected)) {
            "Expected participants should be included in the transaction"
        }
    }

    private fun gatherParticipants(tokens: List<FungibleToken>): Set<PublicKey> {
        val participants : MutableSet<PublicKey> = mutableSetOf()
        if (tokens.isNotEmpty()) {
            tokens.forEach { token ->
                participants.addAll(setOf(token.issuer, token.holder))
            }
        }
        return participants
    }

}