package com.r3.ps.samples.concert.contract

import net.corda.v5.ledger.utxo.Command
import net.corda.v5.ledger.utxo.Contract
import net.corda.v5.ledger.utxo.transaction.UtxoLedgerTransaction

class WalletContract: Contract {

    interface Commands {
        class Create: Command
        class Close: Command
        class Deposit: Command
        class Purchase: Command
        class Charge: Command
    }

    override fun verify(transaction: UtxoLedgerTransaction) {
        when (val command = transaction.commands.single()) {
            is Commands.Create -> verifyCreate(transaction)
            is Commands.Close -> verifyClose(transaction)
            is Commands.Deposit -> verifyDeposit(transaction)
            is Commands.Purchase -> verifyPurchase(transaction)
            is Commands.Charge -> verifyCharge(transaction)
            else ->
                throw IllegalArgumentException("Incorrect action on Wallet: ${command::class.java.name}")
        }

        verifyParticipants(transaction)
    }
    private fun verifyCreate(tx: UtxoLedgerTransaction) {}
    private fun verifyClose(tx: UtxoLedgerTransaction) {}
    private fun verifyDeposit(tx: UtxoLedgerTransaction) {}
    private fun verifyCharge(tx: UtxoLedgerTransaction) {}
    private fun verifyPurchase(tx: UtxoLedgerTransaction) {}
    private fun verifyParticipants(tx: UtxoLedgerTransaction) {}

}