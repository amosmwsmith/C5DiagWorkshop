package com.r3.ps.samples.concert.state

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import net.corda.v5.ledger.utxo.BelongsToContract
import java.security.PublicKey
import java.util.*

@BelongsToContract(FungibleTokenContract::class)
class CashToken(id: UUID = UUID.randomUUID(), issuer: PublicKey, holder: PublicKey, value: Double) :
    FungibleToken(id, issuer, holder, value) {
        fun copy(
            id: UUID = this.id,
            issuer: PublicKey = this.issuer,
            holder: PublicKey = this.holder,
            value: Double = this.value
        ) = CashToken(id, issuer, holder, value)
}

