package com.r3.ps.samples.concert.state.models

import java.util.UUID

data class CashTokenModel(
        val id:UUID,
        val issuer: String,
        val holder: String,
        val value: Double
)
