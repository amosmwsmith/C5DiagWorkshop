package com.r3.ps.samples.concert.state.models

data class WalletModel(
    val id: String,
    val registerWith: String,
    val ownerName: String,
    val cashTokens: List<CashTokenModel>,
    val cashBalance: Double,
    val ticketTokens: List<TicketTokenModel>,
    val ticketsBalance: Map<String, Double>
)