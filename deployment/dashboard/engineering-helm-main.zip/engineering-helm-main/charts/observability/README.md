# Observability stack

A Helm chart to deploy an Observability stack to get Corda metrics and logs.

By default, this chart bootstraps the following main components on a [Kubernetes](http://kubernetes.io) cluster using
the [Helm](https://helm.sh) package manager:

- Prometheus
- Loki
- Promtail
- Grafana
- Prometheus Kafka Exporter _(disabled by default)_
- Prometheus Postgres Exporter _(disabled by default)_

The default chart values will deploy Grafana with the following configuration:

- Datasources:
  - Prometheus (metrics)
  - Loki (logs)
- Dashboards:
  - Corda5
  - Kubernetes cluster
  - Kubernetes workloads
  - Kubernetes pods
  - Kafka
  - Postgres
- Persistence storage enabled.

## Prerequisites

- Kubernetes 1.23+
- Helm 3

## Install Chart

```console
helm install [RELEASE_NAME] observability -n [NAMESPACE]
```

_See [configuration](#configuration) below._

_See [helm install](https://helm.sh/docs/helm/helm_install/) for command documentation._

## Dependencies

By default this chart installs additional, dependent charts:

- [prometheus-community/kube-state-stack](https://github.com/prometheus-community/helm-charts/tree/main/charts/kube-state-metrics)
- [grafana/grafana](https://github.com/grafana/helm-charts/tree/main/charts/grafana)
- [grafana/loki](https://github.com/grafana/loki/tree/main/production/helm/loki)
- [grafana/promtail](https://github.com/grafana/helm-charts/tree/main/charts/promtail)
- [prometheus-community/prometheus-postgres-exporter](https://github.com/prometheus-community/helm-charts/tree/main/charts/prometheus-postgres-exporter)
_(disabled by default)_
- [prometheus-community/prometheus-kafka-exporter](https://github.com/prometheus-community/helm-charts/tree/main/charts/prometheus-kafka-exporter)
_(disabled by default)_

To disable dependencies during installation, set `grafana.enabled`, `kube-prometheus-stack.enabled`, `loki.enabled` or
`promtail.enabled` to `false`.

_See [helm dependency](https://helm.sh/docs/helm/helm_dependency/) for command documentation._

## Uninstall Chart

```console
helm uninstall [RELEASE_NAME]
```

This removes all the Kubernetes components associated with the chart and deletes the release.

_See [helm uninstall](https://helm.sh/docs/helm/helm_uninstall/) for command documentation._

CRDs created by this chart are not removed by default and should be manually cleaned up:

```console
kubectl delete crd alertmanagerconfigs.monitoring.coreos.com
kubectl delete crd alertmanagers.monitoring.coreos.com
kubectl delete crd podmonitors.monitoring.coreos.com
kubectl delete crd probes.monitoring.coreos.com
kubectl delete crd prometheuses.monitoring.coreos.com
kubectl delete crd prometheusrules.monitoring.coreos.com
kubectl delete crd servicemonitors.monitoring.coreos.com
kubectl delete crd thanosrulers.monitoring.coreos.com
```

## Upgrading Chart

```console
helm upgrade [RELEASE_NAME] observability --install
```

_See [helm upgrade](https://helm.sh/docs/helm/helm_upgrade/) for command documentation._

## Configuration

To see all configurable options with detailed comments, visit the chart's [values.yaml](./values.yaml).

### Prometheus Exporters

If deploying Corda with managed services such as AWS MSK, RDS, Aurora, Confluent Cloud, etc., Kafka and Postgres
exporters can be enabled by setting `prometheus-kafka-exporter.enabled` and `prometheus-postgres-exporter.enabled` to
`true`. The credentials for each managed service need to be set in the `values.yaml`.
The following code block can be used as an example for AWS MSK and AWS RDS:

```yaml
prometheus-postgres-exporter:
  enabled: true
  config:
    datasource:
      database: postgres
      host: rds_endpoint
      password: strongpassword
      user: dbadmin

prometheus-kafka-exporter:
  enabled: true
  kafkaServer:
  - boostrap_server_endpoint_1:9096
  - boostrap_server_endpoint_2:9096
  - boostrap_server_endpoint_3:9096
  sasl:
    enabled: true
    handshake: true
    scram:
      enabled: true
      mechanism: scram-sha512
      password: strongpassword
      username: admin
  tls:
    enabled: true
    insecureSkipVerify: true
```

### Corda prereqs Prometheus exporters

If deploying Corda prereqs with the `corda-dev` Helm chart or using the
[Postgres](https://artifacthub.io/packages/helm/bitnami/postgresql) and
[Kafka](https://artifacthub.io/packages/helm/bitnami/kafka) Bitnami Helm charts directly,
Prometheus exporters can be enabled by adding the following configuration on the values:

```yaml
kafka:
  metrics:
    kafka:
      enabled: true
      extraFlags:
        tls.insecure-skip-tls-verify: ""
    jmx:
      enabled: true
    serviceMonitor:
      labels:
        release: [RELEASE_NAME]
      enabled: true

postgresql:
  metrics:
    enabled: true
    serviceMonitor:
      labels:
        release: [RELEASE_NAME]
      enabled: true
```

### Additional Grafana dashboards

In order to deploy additional Grafana dashboards from the Helm chart, place a valid dashboard JSON file in the
[dashboards](./dashboards) folder.
