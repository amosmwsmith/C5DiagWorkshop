package com.r3.ps.samples.concert.state.models

import java.util.*

data class TicketTokenModel(
    val id: UUID,
    val issuer: String,
    val holder: String,
    val value: Double,
    val description: String,
    val price: Double
)