package com.r3.ps.samples.concert.state

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import net.corda.v5.ledger.utxo.BelongsToContract
import java.security.PublicKey
import java.util.*

@BelongsToContract(FungibleTokenContract::class)
class TicketToken(
        id: UUID = UUID.randomUUID(),
        issuer: PublicKey,
        holder: PublicKey,
        value: Double,
        val description: String,
        val price: Double
    ) :
    FungibleToken(id, issuer, holder, value) {
}

