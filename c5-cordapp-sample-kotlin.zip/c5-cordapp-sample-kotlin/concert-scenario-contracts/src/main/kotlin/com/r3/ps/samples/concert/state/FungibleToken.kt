package com.r3.ps.samples.concert.state

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import net.corda.v5.ledger.common.*
import net.corda.v5.ledger.utxo.BelongsToContract
import net.corda.v5.ledger.utxo.ContractState
import java.security.PublicKey
import java.util.UUID

@BelongsToContract(FungibleTokenContract::class)
open class FungibleToken(
    val id: UUID = UUID.randomUUID(),
    val issuer: PublicKey,
    val holder: PublicKey,
    val value: Double
) : ContractState {
    override fun getParticipants(): List<PublicKey> = listOf(issuer, holder)
}