package com.r3.ps.samples.concert.state

import com.r3.ps.samples.concert.contract.WalletContract
import net.corda.v5.ledger.utxo.BelongsToContract
import net.corda.v5.ledger.utxo.ContractState
import java.security.PublicKey
import java.util.UUID
import java.util.UUID.randomUUID

@BelongsToContract(WalletContract::class)
class Wallet(
    val registeredWith: PublicKey,
    val ownerName: String,
    val assets: List<FungibleToken>,
    val id: UUID = randomUUID(),
    participants: MutableList<PublicKey>
    ): ContractState {

    private val participants = participants

    fun listCashTokens(): List<CashToken> = assets.filterIsInstance<CashToken>()
    fun listTicketTokens(): List<TicketToken> = assets.filterIsInstance<TicketToken>()
    fun balance(): Pair<Double, Map<String, Double>> {
        var cashBalance = 0.0
        val ticketsBalance: MutableMap<String, Double> = mutableMapOf()
        assets.forEach {
            if (it is CashToken) cashBalance += it.value
            if (it is TicketToken) {
                if (ticketsBalance[it.description] != null) {
                    ticketsBalance[it.description] = ticketsBalance[it.description]!! + it.value
                } else { ticketsBalance[it.description] = (it.value) }
            }
        }
        return Pair(cashBalance, ticketsBalance)
    }
    fun copy(
        registeredWith: PublicKey = this.registeredWith,
        ownerName: String = this.ownerName,
        assets: List<FungibleToken> = this.assets,
        id: UUID = this.id,
        participants: MutableList<PublicKey> = this.participants
    ) = Wallet(registeredWith, ownerName, assets, id, participants)

    fun deposit(assets: List<FungibleToken>): Wallet =
        this.copy(assets = this.assets.toList() + assets)
    fun deposit(asset: FungibleToken) = deposit(listOf(asset))

    fun pop(assets: List<FungibleToken>): Wallet =
        this.copy(assets = this.assets.toList() - assets.toSet())
    fun pop(asset: FungibleToken) = pop(listOf(asset))
    override fun getParticipants(): MutableList<PublicKey> {
        return participants
    }

}