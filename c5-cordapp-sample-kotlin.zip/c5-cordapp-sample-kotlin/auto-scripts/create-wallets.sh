#!/bin/bash

for i in {0..1000}
do
  epoch=$(date +%s)
  curl -k --location 'https://localhost:8888/api/v1/flow/4D67C7AFB635' \
  --header 'Authorization: Basic YWRtaW46S0t0ckVKY1lIZW93' \
  --header 'Content-Type: application/json' \
  --data '{
      "clientRequestId" : "create-wallet-payee-'$epoch'",
      "flowClassName" : "com.r3.ps.samples.concert.workflow.CreateWalletFlow",
      "requestBody": {
          "ownerName" : "Payee-'$epoch'",
          "registerWith" : "CN=PSP1, OU=Test Dept, O=R3, L=London, C=GB"
      }

  }'
  curl -k --location 'https://localhost:8888/api/v1/flow/4D67C7AFB635' \
  --header 'Authorization: Basic YWRtaW46S0t0ckVKY1lIZW93' \
  --header 'Content-Type: application/json' \
  --data '{
      "clientRequestId" : "create-wallet-payer-'$epoch'",
      "flowClassName" : "com.r3.ps.samples.concert.workflow.CreateWalletFlow",
      "requestBody": {
          "ownerName" : "Payee-'$epoch'",
          "registerWith" : "CN=PSP1, OU=Test Dept, O=R3, L=London, C=GB"
      }

  }'
  sleep 1
done