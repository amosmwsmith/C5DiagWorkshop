# Corda 5 PS Sample CorDapps
Based on the Corda 5 CSDE sample CorDapp

The following CorDapps exist here:
* chat - a simple CorDapp that chats between two nodes

Each CorDapp includes:
* JUnit tests that run using the nifty C5 Simulator
* Cucumber-based integration tests that run against a locally-running C5 CombinedWorker deployment (see below for details) 
* JMeter-based load tests that run against the same locally-running C5 deployment

## Running up a C5 CombinedWorker for testing

Change to the CorDapp directory:
```
$ cd <cordapp dir>
```
Start up Corda 5 CombinedWorker - the gradle task completes, but Corda takes a little while to come up, so check progress in logs/corda.log. This also starts up a PostgreSQL container as well.
```
$ ../gradlew startCorda
```
Build the CorDapp...
```
$ ../gradlew clean build
```
Package & upload the CorDapp CPI, deploy the VNodes defined in config/dev-net.json, all using a single CSDE command:
```
$ ../gradlew quickDeployCordapp
```
And finally, run the integration tests:
```
$ ../gradlew integrationTest
```
Win!

## Load-testing

There is a JMeter load-test script in the src/load-test/jmeter folder. The cordapp build script includes a Gradle-JMeter plugin (https://github.com/qualersoft/jmeter-gradle-plugin) that allows the load-tests to be run headless from gradle:

```
$ ../gradlew runJMeter
```
Note that the load-test needs the C5 CombinedWorker to be running locally, similar to the integration tests.
