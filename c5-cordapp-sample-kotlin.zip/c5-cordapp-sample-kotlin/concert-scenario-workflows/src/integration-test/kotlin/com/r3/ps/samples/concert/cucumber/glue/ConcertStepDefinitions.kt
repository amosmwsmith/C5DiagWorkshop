package com.r3.ps.samples.concert.cucumber.glue

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.r3.ps.samples.concert.workflow.*

import io.cucumber.cienvironment.internal.com.eclipsesource.json.Json
import io.cucumber.datatable.DataTable
import io.cucumber.java.en.Then
import io.cucumber.java.en.When
import org.hamcrest.MatcherAssert
import java.util.*

class ConcertStepDefinitions {

    val coreStepDefinitions = CoreStepDefinitions()

    lateinit var requestId: UUID
    lateinit var creatorShortHash: String
    lateinit var tokenIds: List<String>

    val wallets: MutableMap<String, UUID> = mutableMapOf()


    @When("{string} issues {string} cash tokens")
    fun issue_cash_tokens(
        memberX500Name: String,
        rawValues: String
    ) {
        val values = rawValues.replace(", ", ",").split(',').map {
            it.toDouble()
        }
        val issuer = coreStepDefinitions.getShortHashForX500Name(memberX500Name)
        creatorShortHash = issuer
        val requestIds = values.map { value ->
            coreStepDefinitions.createFlowRequest(
                issuer,
                "com.r3.ps.samples.concert.workflow.CashTokenIssueFlow",
                mapOf(
                    Pair("issuer", memberX500Name),
                    Pair("value", value)
                )
            )
        }
        val results = requestIds.map {
            coreStepDefinitions.waitForFlowResponse(issuer, it)
        }.forEach { result ->
            MatcherAssert.assertThat(
                "Issue flow returned an error: $result",
                !result.contains("Couldn't issue token on")
            )
        }
    }



    @Then("{string} can see just issued cash token with value {double}")
    fun get_issued_cash_token(memberX500Name: String, value: Double) {
        val issuer = coreStepDefinitions.getShortHashForX500Name(memberX500Name)
        requestId = coreStepDefinitions.createFlowRequest(
            issuer,
            "com.r3.ps.samples.concert.workflow.ListCashTokensFlow",
            emptyMap()
        )
        val result = coreStepDefinitions.waitForFlowResponse(issuer, requestId)
        MatcherAssert.assertThat("At list one token with value $value should be present",
            Json.parse(result).asObject().get("tokens").asArray().any { it.asObject().get("value").asDouble() == value }
        )
    }

    @When("{string} has no tokens")
    fun redeem_all_tokens(memberX500Name: String) {
        val issuer = coreStepDefinitions.getShortHashForX500Name(memberX500Name)
        requestId = coreStepDefinitions.createFlowRequest(
            issuer,
            "com.r3.ps.samples.concert.workflow.RedeemAllTokens",
            mapOf("whyAmI" to "required?")
        )
        coreStepDefinitions.waitForFlowResponse(issuer, requestId)
    }

    @When("{string} issues {string} tickets for {string} with price {double} per each")
    fun issue_tickets_tokens(
        memberX500Name: String,
        rawValues: String,
        description: String,
        price: Double
    ) {
        val values = rawValues.replace(", ", ",").split(',').map {
            it.toDouble()
        }
        val issuer = coreStepDefinitions.getShortHashForX500Name(memberX500Name)
        creatorShortHash = issuer
        val requestIds = values.map { value ->
            coreStepDefinitions.createFlowRequest(
                issuer,
                "com.r3.ps.samples.concert.workflow.TicketTokenIssueFlow",
                mapOf(
                    Pair("issuer", memberX500Name),
                    Pair("value", value),
                    Pair("description", description),
                    Pair("price", price)
                )
            )
        }
        val results = requestIds.map {
            coreStepDefinitions.waitForFlowResponse(issuer, it)
        }.forEach { result ->
            MatcherAssert.assertThat(
                "Issue flow returned an error: $result",
                !result.contains("Couldn't issue token on")
            )
        }
    }

    @Then("{string} can see just issued tickets for {string} with value {double}")
    fun get_issued_ticket_token(memberX500Name: String, description: String, value: Double) {
        val issuer = coreStepDefinitions.getShortHashForX500Name(memberX500Name)
        requestId = coreStepDefinitions.createFlowRequest(
            issuer,
            "com.r3.ps.samples.concert.workflow.ListTicketTokensFlow",
            emptyMap()
        )
        val result = coreStepDefinitions.waitForFlowResponse(issuer, requestId)
        MatcherAssert.assertThat("At list one ticket token with value $value and description $description should be present",
            Json.parse(result).asObject().get("tokens").asArray().any {
                it.asObject().get("value").asDouble() == value
                        && it.asObject().get("description").asString() == description }
        )
    }

    @When("{string} can register a wallet with {string}")
    fun register_a_wallet(owner: String, registerWith: String) {
        val issuer = coreStepDefinitions.getShortHashForX500Name(registerWith)
        val requestId = coreStepDefinitions.createFlowRequest(
            issuer,
            "com.r3.ps.samples.concert.workflow.CreateWalletFlow",
            mapOf(
                Pair("ownerName", owner),
                Pair("registerWith", registerWith)
            )
        )
        val result = coreStepDefinitions.waitForFlowResponse(issuer, requestId)
        MatcherAssert.assertThat("A new wallet should be created", with(Json.parse(result).asObject()) {
            get("ownerName").asString() == owner
            && get("registerWith").asString() == registerWith
            && get("id").asString().isNullOrBlank() != true
        })
    }

    @Then("{string} has a wallet with {string}")
    fun wallet_exists(owner: String, registerWith: String) {
        val bank = coreStepDefinitions.getShortHashForX500Name(registerWith)
        val requestId = coreStepDefinitions.createFlowRequest(
            bank,
            "com.r3.ps.samples.concert.workflow.ListWallets",
            emptyMap()
        )
        val result = coreStepDefinitions.waitForFlowResponse(bank, requestId)
        MatcherAssert.assertThat("There is at least one wallet registered for $owner",Json.parse(result).asArray().any {
            it.asObject().get("ownerName").asString() == owner
        })
    }

    @Then("{string} can destroy all related wallets registered with {string}")
    fun destroy_wallet(owner: String, registerWith: String) {
        val bank = coreStepDefinitions.getShortHashForX500Name(registerWith)
        var requestId = coreStepDefinitions.createFlowRequest(
            bank,
            "com.r3.ps.samples.concert.workflow.ListWallets",
            emptyMap()
        )
        var result = coreStepDefinitions.waitForFlowResponse(bank, requestId)
        val ids = Json.parse(result).asArray().filter {
            it.asObject().get("ownerName").asString() == owner
        }.forEach {
            val id = it.asObject().get("id")
            result = coreStepDefinitions.waitForFlowResponse(bank,
                coreStepDefinitions.createFlowRequest(
                    bank,
                    "com.r3.ps.samples.concert.workflow.DestroyWallet",
                    mapOf(Pair("id", id))
            ))
            val message = Json.parse(result).asString()
            MatcherAssert.assertThat("Wallet should be successfully destroyed", !message.contains("Error: "))
        }
    }

}
