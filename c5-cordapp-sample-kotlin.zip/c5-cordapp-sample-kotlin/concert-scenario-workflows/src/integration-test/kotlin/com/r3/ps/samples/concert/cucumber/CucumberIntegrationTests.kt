package com.r3.ps.samples.concert.cucumber

import io.cucumber.java.Before
import io.restassured.RestAssured
import io.restassured.filter.log.RequestLoggingFilter
import io.restassured.filter.log.ResponseLoggingFilter
import org.junit.platform.suite.api.IncludeEngines
import org.junit.platform.suite.api.SelectClasspathResource
import org.junit.platform.suite.api.Suite

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("com/r3/ps/samples/concert/cucumber")
open class CucumberIntegrationTests {

    @Before
    fun setup() {
        RestAssured.filters(RequestLoggingFilter(), ResponseLoggingFilter())
    }
}
