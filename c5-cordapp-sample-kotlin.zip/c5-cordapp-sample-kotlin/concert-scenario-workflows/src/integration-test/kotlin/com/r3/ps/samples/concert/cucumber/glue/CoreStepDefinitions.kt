package com.r3.ps.samples.concert.cucumber.glue

import io.cucumber.java.en.Given
import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.response.Response
import org.hamcrest.MatcherAssert
import org.hamcrest.Matchers
import java.util.*

class CoreStepDefinitions {

    private var cordaRpcUsername = "admin"
    private var cordaRpcPassword = "admin"

    @Given("a virtualnode exists for X500Name {string}")
    fun assert_vnode_exists(x500Name: String) {
        MatcherAssert.assertThat(getShortHashForX500Name(x500Name), Matchers.notNullValue())
    }

    @Given("a virtual node exists for X500Name {string}")
    fun assert_vnode_exists_alias(x500Name: String) {
        assert_vnode_exists(x500Name)
    }

    fun getShortHashForX500Name(x500Name: String): String {
        println(cordaRpcPassword)
        val jsonPathStr =
            "virtualNodes.find{ it.holdingIdentity.x500Name==\"$x500Name\" }.holdingIdentity.shortHash"
        return RestAssured
            .given()
            .relaxedHTTPSValidation()
            .auth().basic(cordaRpcUsername, cordaRpcPassword)
            .contentType(ContentType.JSON)
            .`when`()
            .get("https://localhost:8888/api/v1/virtualnode").jsonPath().getString(jsonPathStr)
    }

    fun createFlowRequest(initiatorShortHash: String, flowClassname: String, requestData: Map<String, Any>): UUID {
        val requestId = UUID.randomUUID()
        val response = RestAssured
            .given()
            .relaxedHTTPSValidation()
            .auth().basic(cordaRpcUsername, cordaRpcPassword)
            .contentType(ContentType.JSON)
            .body(createRequestBody(requestId, flowClassname, requestData))
            .`when`()
            .post("https://localhost:8888/api/v1/flow/$initiatorShortHash")
        MatcherAssert.assertThat(response.statusCode, Matchers.equalTo(202))
        return requestId
    }

    fun createRequestBody(
        clientRequestId: UUID,
        flowClassname: String,
        requestData: Map<String, Any>
    ): Map<String, Any> {
        return mapOf(
            Pair("clientRequestId", clientRequestId.toString()),
            Pair("flowClassName", flowClassname),
            Pair("requestBody", requestData)
        )
    }

    fun waitForFlowResponse(initiatorShortHash: String, clientRequestId: UUID): String {
        val flowStatusJsonPathStr =
            "flowStatus"
//            "flowStatusResponses.find{ it.clientRequestId==\"${clientRequestId.toString()}\" }.flowStatus"
        val flowResultJsonPathStr =
            "flowResult"
//            "flowStatusResponses.find{ it.clientRequestId==\"${clientRequestId.toString()}\" }.flowResult"

        var response: Response
        do {
            response = RestAssured
                .given()
                .relaxedHTTPSValidation()
                .auth().basic(cordaRpcUsername, cordaRpcPassword)
                .contentType(ContentType.JSON)
                .`when`()
                .get("https://localhost:8888/api/v1/flow/$initiatorShortHash/$clientRequestId")
            println(
                "Checking for completion of flow with clientRequestId=$clientRequestId, flow is ${
                    response.jsonPath().getString(flowStatusJsonPathStr)
                }"
            )

            when (response.jsonPath().getString(flowStatusJsonPathStr)) {
                "COMPLETED" -> return response.jsonPath().getString(flowResultJsonPathStr)
                "FAILED" -> throw AssertionError("Flow invocation ${clientRequestId} failed. ${response.body}")
            }

            Thread.sleep(3000)
        } while (true)
    }
}
