package com.r3.ps.samples.concert.workflow

import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable


class RedeemAllTokens : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        return try {

            val tokens = flowEngine.subFlow(ListCashTokens()) + flowEngine.subFlow(ListTicketTokens())
            if (tokens.isEmpty()) "OK"
            else {
                flowEngine.subFlow(RedeemTokenFlow(tokens.map { it.state.contractState.id }))
                "OK"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            logger.error("RedeemAll failed because: $e")
            "Not OK"
        }
    }
}