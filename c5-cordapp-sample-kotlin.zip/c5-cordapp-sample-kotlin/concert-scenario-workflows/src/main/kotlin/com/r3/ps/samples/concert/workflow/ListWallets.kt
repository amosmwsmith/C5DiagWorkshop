package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.Wallet
import com.r3.ps.samples.concert.workflow.models.ListWalletsRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef

class ListWallets : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        val request = requestBody.getRequestBodyAs(json, ListWalletsRequest::class.java)
        val models = flowEngine.subFlow(ListWalletsFlow(request.ids ?: emptyList<String>())).map {
            it.state.contractState.toModel()
        }
        return json.format(models)
    }
}

