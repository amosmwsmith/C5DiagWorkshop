package com.r3.ps.samples.concert.workflow.models

import com.r3.ps.samples.concert.state.models.CashTokenModel

data class ListCashTokensResponse(
    val tokens: List<CashTokenModel>?,
    val totalCount: Int,
)
