package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.workflow.models.MoveTokenRequest
import com.r3.ps.samples.concert.workflow.models.ShareTokenRequest
import net.corda.v5.application.flows.*
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable
import kotlin.Exception

@InitiatingFlow(protocol = "share-cash-token")
class ShareCashToken : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
        val request = requestBody.getRequestBodyAs(json, ShareTokenRequest::class.java)
        val token = flowEngine.subFlow(ListCashTokens(listOf(request.id))).getOrNull(0) ?: throw Exception("ShareCashToken: no token found")
        val shareWith = findParty(request.shareWith)
        val tx = ledger.transactionBuilder
            .setNotary(notary)
            .setTimeWindowUntil(defaultTimeWindow)
            .addInputState(token.ref)
            .addOutputState(token.state.contractState)
            .addCommand(FungibleTokenContract.Commands.Share())
            .addSignatories(token.state.contractState.participants + shareWith.owningKey)
        val stx = tx.toSignedTransaction()
        val sessions = listOf( flowMessaging.initiateFlow(shareWith.name))
        ledger.finalize(stx, sessions)
        return "Ok"
        } catch (e : Exception) {
            e.printStackTrace()
            logger.error("Share Cash Token failed because ${e.message}")
            throw e
        }
    }
}

@InitiatedBy(protocol = "share-cash-token")
class ShareCashTokenResponder: AbstractFlow(), ResponderFlow {
    @Suspendable
    override fun call(session: FlowSession) {
        ledger.receiveFinality(session) {}
    }

}