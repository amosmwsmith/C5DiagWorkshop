package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.workflow.models.ListCashTokensResponse
import com.r3.ps.samples.concert.workflow.models.ListTokensRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef

class ListCashTokensFlow : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        val request = requestBody.getRequestBodyAs(json, ListTokensRequest::class.java)

        val cashTokens = flowEngine.subFlow(ListCashTokens(request.tokenIds))
            .map { it.state.contractState.toModel() }

        val result = ListCashTokensResponse(
            tokens = cashTokens,
            totalCount = cashTokens.size
        )

        return json.format(result)
    }
}

class ListCashTokens(private val filterIds: List<String>? = null) : AbstractFlow(), SubFlow<List<StateAndRef<CashToken>>> {
    constructor(filterId: String) : this(listOf(filterId))
    @Suspendable
    override fun call(): List<StateAndRef<CashToken>> {
        val list = ledger.findUnconsumedStatesByType(CashToken::class.java).map { it }
            .sortedBy { it.state.contractState.id }
        if (!filterIds.isNullOrEmpty()) {
            return list.filter { filterIds.contains(it.state.contractState.id.toString()) }
        }
        return list
    }
}
