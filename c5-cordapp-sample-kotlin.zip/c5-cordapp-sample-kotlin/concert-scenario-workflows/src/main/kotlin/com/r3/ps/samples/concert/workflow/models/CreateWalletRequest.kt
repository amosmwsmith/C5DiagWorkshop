package com.r3.ps.samples.concert.workflow.models

data class CreateWalletRequest(
    val ownerName: String,
    val registerWith: String?
)