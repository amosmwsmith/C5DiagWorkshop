package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import com.r3.ps.samples.concert.state.FungibleToken
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.base.annotations.Suspendable


@InitiatingFlow(protocol = "issue-token")
class TokenIssueFlow(
    private val token: FungibleToken
) : AbstractFlow(), SubFlow<String> {

    @Suspendable
    override fun call(): String =
        try {
            val issuer = token.issuer
            // TODO: check if self is eligible to issue new tokens <- how would we pass configuration to CorDapp?
            // TODO: [Q] Should this check be moved to the contract instead?
            if (!memberLookup.myInfo().ledgerKeys.contains(issuer)) {
                throw IllegalArgumentException("${memberLookup.myInfo().name} can't issue token on behalf of $issuer")
            }
            val stx = ledger.transactionBuilder
                .setNotary(notary)
                .addCommand(FungibleTokenContract.Commands.Issue())
                .addOutputState(token)
                .setTimeWindowUntil(defaultTimeWindow)
                .addSignatories(listOf(token.issuer))
                .toSignedTransaction()
            ledger.finalize(stx, emptyList())
            token.id.toString()
        } catch (e: Exception) {
            "Couldn't issue token on ${memberLookup.myInfo().name} because $e"
        }
}