package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.workflow.models.ListCashTokensResponse
import com.r3.ps.samples.concert.workflow.models.SplitTokensRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable
import kotlin.math.abs

class SplitCashTokens : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
            val splitRequest = requestBody.getRequestBodyAs(json, SplitTokensRequest::class.java)
            return json.format(flowEngine.subFlow(SplitCashTokensFlow(splitRequest.tokenId, splitRequest.chunks)))
    }
}