package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.WalletContract
import com.r3.ps.samples.concert.state.Wallet
import com.r3.ps.samples.concert.state.models.WalletModel
import com.r3.ps.samples.concert.workflow.models.CreateWalletRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable

class CreateWalletFlow : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val request = requestBody.getRequestBodyAs(json, CreateWalletRequest::class.java)
            val issuer = if (request.registerWith != null) {
                findParty(request.registerWith).owningKey
            } else memberLookup.myInfo().sessionInitiationKey
            val wallet = Wallet(
                issuer,
                request.ownerName,
                assets = mutableListOf(),
                participants = mutableListOf(issuer)
            )
            val stx = ledger.transactionBuilder
                .setNotary(notary)
                .addCommand(WalletContract.Commands.Create())
                .addOutputState(wallet)
                .setTimeWindowUntil(defaultTimeWindow)
                .addSignatories(wallet.participants)
                .toSignedTransaction()

            val ftx = ledger.finalize(stx, emptyList())
            with(ftx.toLedgerTransaction().getOutputStates(Wallet::class.java).first()) {
                val balance = balance()
                return json.format(
                    WalletModel(
                        id = id.toString(),
                        registerWith = registeredWith.toPrettyName(),
                        ownerName = ownerName,
                        cashTokens = listCashTokens().map {
                            it.toModel()
                        },
                        cashBalance = balance.first,
                        ticketTokens = listTicketTokens().map {
                            it.toModel()
                        },
                        ticketsBalance = balance.second
                    )
                )
            }

        } catch (e: Exception) {
            return "Couldn't create wallet on ${memberLookup.myInfo().name} because $e"
        }
    }
}