package com.r3.ps.samples.concert.workflow.models

class MoveTokenRequest(
    val id: String,
    val newHolder: String
)