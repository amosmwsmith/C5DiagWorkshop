package com.r3.ps.samples.concert.workflow.models

data class ListWalletsRequest(
    val ids: List<String>? = emptyList()
)