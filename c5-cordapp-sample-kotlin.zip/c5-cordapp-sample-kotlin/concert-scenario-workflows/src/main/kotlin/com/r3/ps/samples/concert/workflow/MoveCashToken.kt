package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.state.FungibleToken
import com.r3.ps.samples.concert.workflow.models.MoveTokenRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef
import kotlin.math.log

class MoveCashToken: AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val request = requestBody.getRequestBodyAs(json, MoveTokenRequest::class.java)
            val token = flowEngine.subFlow(ListCashTokens(listOf(request.id))).getOrNull(0) ?: throw java.lang.Exception("MoveCash couldn't find the original token with id ${request.id}")
            val newToken = token.state.contractState.copy(
                holder = findParty(request.newHolder).owningKey
            )
            val afterMove = flowEngine.subFlow(MoveFungibleToken(token as StateAndRef<FungibleToken>, newToken))
            return json.format(afterMove.id)
//            return json.format(flowEngine.subFlow(MoveFungibleToken(tokenStateRef[0], newToken)))
        } catch (e: Exception) {
            e.printStackTrace()
            logger.error("MoveCash failed because ${e.message}")
            throw e
        }
    }
}