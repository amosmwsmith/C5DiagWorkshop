package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.contract.FungibleTokenContract
import com.r3.ps.samples.concert.state.FungibleToken
import net.corda.v5.application.flows.InitiatedBy
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.ResponderFlow
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef

@InitiatingFlow(protocol = "split-token")
class SplitFungibleToken(
    private val token: StateAndRef<FungibleToken>,
    private val newTokens: List<FungibleToken>
) : AbstractFlow(), SubFlow<List<FungibleToken>> {
    @Suspendable
    override fun call(): List<FungibleToken> {
        if (!memberLookup.myInfo().ledgerKeys.contains(token.state.contractState.holder))
            throw IllegalArgumentException("Token split should be initiated by current holder (${token.state.contractState.holder.toPrettyName()})")
        val signatories = token.state.contractState.participants
        val sessions =
            (signatories - token.state.contractState.holder).map { flowMessaging.initiateFlow(it.toMember()) }
        val stx = ledger.transactionBuilder
            .setNotary(notary)
            .addCommand(FungibleTokenContract.Commands.Split())
            .addInputState(token.ref)
            .addOutputStates(newTokens)
            .setTimeWindowUntil(defaultTimeWindow)
            .addSignatories(signatories)
            .toSignedTransaction()
        ledger.finalize(stx, sessions)
        return newTokens
    }
}

@InitiatedBy(protocol = "split-token")
class SplitFungibleTokenResponder : AbstractFlow(), ResponderFlow {
    @Suspendable
    override fun call(session: FlowSession) {
        ledger.receiveFinality(session) {
            logger.info("SplitFungibleTokenResponder: hiya! I am ${memberLookup.myInfo().name}")
        }
    }
}