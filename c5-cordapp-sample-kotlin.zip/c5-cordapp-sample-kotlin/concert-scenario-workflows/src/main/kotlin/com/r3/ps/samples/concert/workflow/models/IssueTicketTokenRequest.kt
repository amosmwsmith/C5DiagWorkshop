package com.r3.ps.samples.concert.workflow.models

data class IssueTicketTokenRequest(
    val value: Double,
    val issuer: String,
    val description: String,
    val price: Double
)

