package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.workflow.models.IssueTokenRequest
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.base.annotations.Suspendable
import kotlin.random.Random

@InitiatingFlow(protocol = "cash")
class CashTokenIssueFlow : AbstractFlow(), ClientStartableFlow {
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {

            val issueRequest = requestBody.getRequestBodyAs(json, IssueTokenRequest::class.java)
            val issuer = findParty(issueRequest.issuer).owningKey
            val token = CashToken(
                issuer = issuer,
                holder = issuer,
                value = issueRequest.value
            )
            var x:Double = 1.0
            for (i in 1..1300) {
                x = x + 1
                for (i2 in 1..1300) {
                    x = x - 1
                    for (i3 in 1..600) {
                        x = x + Random.nextDouble(7.0)
                    }
                }
            }
            val num = Random.nextInt(5)
            logger.info("Random amount is: $x - v6")
            if(num == 4)
                throw UnsupportedOperationException("Random number is: $num and Random double is $x - v6")
            return flowEngine.subFlow(TokenIssueFlow(token))
        } catch (e: Exception) {
            logger.error("CashToken Issuance failed on this occasion because: $e")
            throw e
        }
    }
}