package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.Wallet
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.StateAndRef

class ListWalletsFlow(
    val ids: List<String>
) : AbstractFlow(), SubFlow<List<StateAndRef<Wallet>>> {
    constructor(id: String): this(listOf(id))
    @Suspendable
    override fun call(): List<StateAndRef<Wallet>> {
        val wallets = ledger.findUnconsumedStatesByType(Wallet::class.java).sortedBy { it.state.contractState.id }
        return if (ids.isNotEmpty()) {
            wallets.filter { ids.contains(it.state.contractState.id.toString()) }
        } else wallets
    }
}