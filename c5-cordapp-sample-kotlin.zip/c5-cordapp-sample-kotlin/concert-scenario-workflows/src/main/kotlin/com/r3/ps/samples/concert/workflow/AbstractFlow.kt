package com.r3.ps.samples.concert.workflow

import com.r3.ps.samples.concert.state.CashToken
import com.r3.ps.samples.concert.state.TicketToken
import com.r3.ps.samples.concert.state.Wallet
import com.r3.ps.samples.concert.state.models.CashTokenModel
import com.r3.ps.samples.concert.state.models.TicketTokenModel
import com.r3.ps.samples.concert.state.models.WalletModel
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.common.Party
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.membership.MemberInfo
import org.slf4j.LoggerFactory
import java.security.PublicKey
import java.time.Instant
import java.time.temporal.ChronoUnit

abstract class AbstractFlow {
    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @CordaInject
    lateinit var json: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var ledger: UtxoLedgerService

    @CordaInject
    lateinit var flowEngine: FlowEngine

    private val _members: HashMap<String, MemberInfo?> = hashMapOf()
    private val _membersByKey: HashMap<PublicKey, MemberInfo?> = hashMapOf()

    companion object {
        val logger = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    /**
     * Returns identity of the notary on the network.
     * Throws an exception if there is more than one notary is present.
     */
    val notary: Party
        @Suspendable
        get() {
            try {
                // TODO: [Q] Should we have selection of the first notary from the box?
                val notaryInfo = notaryLookup.notaryServices.single()
                val notaryKey = memberLookup.lookup().single {
                    it.memberProvidedContext["corda.notary.service.name"] == notaryInfo.name.toString()
                }.ledgerKeys.first()
                return Party(notaryInfo.name, notaryKey)
            } catch (e: Exception) {
                logger.error("Couldn't find notary virtual node! E: $e")
                throw e
            }
        }

    /**
     * Returns [Party] if the identity is present on the network.
     * Throws [IllegalArgumentException] if lookup was failed.
     **/
    @Suspendable
    fun findParty(name: String) =
        _members.getOrElse(name) {
            val member = memberLookup.lookup(MemberX500Name.parse(name))
            member
        }?.let { Party(it.name, it.ledgerKeys.first()) }
            ?: throw IllegalArgumentException("The identity $name does not exist within the network")

//            ?.let { Party(it.name, it.ledgerKeys.first()) }
//            ?: throw IllegalArgumentException("The identity $name does not exist within the network")


    /**
     * Duration of a day from now.
     */
    val defaultTimeWindow: Instant
        @Suspendable
        get() = Instant.now().plus(1, ChronoUnit.DAYS)

    @Suspendable
    fun PublicKey.toMember(): MemberX500Name =
        _membersByKey.getOrElse(this) {
            val member = memberLookup.lookup(this)
            _membersByKey[this] = member
            member
        }?.name ?: throw IllegalArgumentException("Couldn't find identity for given public key")


    fun PublicKey.toPrettyName(): String =
        toMember().toString()

    fun CashToken.toModel(): CashTokenModel = CashTokenModel(
        id = id,
        issuer = issuer.toPrettyName(),
        holder = holder.toPrettyName(),
        value = value
    )

    fun CashTokenModel.toState(): CashToken = CashToken(
        id = id,
        value = value,
        issuer = findParty(issuer).owningKey,
        holder = findParty(holder).owningKey
    )

    fun TicketToken.toModel(): TicketTokenModel = TicketTokenModel(
        id = id,
        issuer = issuer.toPrettyName(),
        holder = holder.toPrettyName(),
        description = description,
        value = value,
        price = price
    )

    fun TicketTokenModel.toState(): TicketToken = TicketToken(
        id = id,
        issuer = findParty(issuer).owningKey,
        holder = findParty(holder).owningKey,
        description = description,
        value = value,
        price = price
    )

    fun Wallet.toModel(): WalletModel {
        val theBalance = balance()
        return WalletModel(
            id = id.toString(),
            ownerName = ownerName,
            cashTokens = listCashTokens().map { token -> token.toModel() },
            cashBalance = theBalance.first,
            ticketTokens = listTicketTokens().map { token -> token.toModel() },
            ticketsBalance = theBalance.second,
            registerWith = registeredWith.toPrettyName()
        )
    }
}