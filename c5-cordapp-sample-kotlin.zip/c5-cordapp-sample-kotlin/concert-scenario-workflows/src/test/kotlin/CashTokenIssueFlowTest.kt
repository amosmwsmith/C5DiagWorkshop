//import com.r3.ps.samples.concert.workflow.CashTokenIssueFlow
//import com.r3.ps.samples.concert.workflow.TokenIssueFlow
//import com.r3.ps.samples.concert.workflow.models.IssueTokenRequest
//import net.corda.simulator.RequestData
//import net.corda.simulator.Simulator
//import net.corda.simulator.crypto.HsmCategory
//import net.corda.v5.base.types.MemberX500Name
//import org.junit.jupiter.api.Disabled
//import org.junit.jupiter.api.Test
//
//class CashTokenIssueFlowTest {
//    private val PSP1 = MemberX500Name.parse("CN=PSP1, OU=Test Dept, O=R3, L=London, C=GB")
//    private val Notary = MemberX500Name.parse("CN=NotaryRep1, OU=Test Dept, O=R3, L=London, C=GB")
//    @Disabled
//    @Test
//    fun `can issue some cash on PSP1`() {
//        val simulator = Simulator()
//        val psp1VN = simulator.createVirtualNode(PSP1, CashTokenIssueFlow::class.java, TokenIssueFlow::class.java)
//        psp1VN.generateKey("LEDGER", HsmCategory.LEDGER, "ECDSA")
//        val data = IssueTokenRequest(100.45, PSP1.toString())
//        val request = RequestData.create(
//            "req no 1",
//            CashTokenIssueFlow::class.java,
//            data
//        )
//        val flowResponse = psp1VN.callFlow(request)
//
//        assert(!flowResponse.contains("Couldn't issue token on"))
//        // TODO: [Q] How can I check what's in the vault?
//    }
//}
