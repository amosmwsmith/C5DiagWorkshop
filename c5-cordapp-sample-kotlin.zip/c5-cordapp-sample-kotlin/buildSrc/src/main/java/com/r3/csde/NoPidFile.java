package com.r3.csde;

public class NoPidFile extends Exception {
    public NoPidFile(String message){
        super(message);
    }
}