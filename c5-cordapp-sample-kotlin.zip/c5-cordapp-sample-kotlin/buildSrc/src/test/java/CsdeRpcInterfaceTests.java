import com.r3.csde.CsdeRpcInterface;

public class CsdeRpcInterfaceTests {
}
